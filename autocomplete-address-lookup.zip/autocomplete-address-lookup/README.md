# Autocomplete Address Lookup

A Pen created on CodePen.io. Original URL: [https://codepen.io/slaterjohn/pen/abzZeOe](https://codepen.io/slaterjohn/pen/abzZeOe).

Allow your customer to search for their address, as they type, and auto-fill your standard predefined address fields. This is a no-fuss integration that means you need to edit very little of your existing code.