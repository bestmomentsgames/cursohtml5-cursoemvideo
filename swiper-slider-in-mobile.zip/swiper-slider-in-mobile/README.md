# Swiper slider in mobile

A Pen created on CodePen.io. Original URL: [https://codepen.io/hyoyeongkim/pen/JjowZLO](https://codepen.io/hyoyeongkim/pen/JjowZLO).

Responsive and beautiful  swiper slider in mobile view
easy to customize option