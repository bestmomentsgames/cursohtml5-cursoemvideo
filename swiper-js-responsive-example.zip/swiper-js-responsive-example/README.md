# Swiper.JS Responsive example.

A Pen created on CodePen.io. Original URL: [https://codepen.io/MattWindle/pen/OJOOoBq](https://codepen.io/MattWindle/pen/OJOOoBq).

